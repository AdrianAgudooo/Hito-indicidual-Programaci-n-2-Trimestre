<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Consultas</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container">
        <h1>Consultas</h1>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>Email</th>
                    <th>Título</th>
                    <th>Fecha de publicación</th>
                    <th>Imagen</th>
                    <th>Contenido</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
            <?php
            $servername = "localhost";
            $username = "root";
            $password = "";
            $dbname = "hitoindividual2trimestre";

            $conn = mysqli_connect($servername, $username, $password, $dbname);

            if (!$conn) {
                die("Error al conectar a la base de datos: " . mysqli_connect_error());
            }

            $sql = "SELECT * FROM formulario";
            $result = mysqli_query($conn, $sql);

            while ($row = mysqli_fetch_assoc($result)) {
                echo "<tr>";
                echo "<td>" . $row["email"] . "</td>";
                echo "<td>" . $row["titulo"] . "</td>";
                echo "<td>" . $row["fechapublicacion"] . "</td>";
                echo "<td><img src='uploads/" . $row["imagen"] . "' height='100'></td>";
                echo "<td>" . $row["contenido"] . "</td>";
                echo "<td>";
                echo "<a class='btn btn-danger disabled' href='#'>Eliminar</a>";
                echo "<a class='btn btn-primary disabled' href='#'>Actualizar</a>";
                echo "</td>";
                echo "</tr>";
            }

            mysqli_close($conn);
            ?>
            </tbody>
        </table>
    </div>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>