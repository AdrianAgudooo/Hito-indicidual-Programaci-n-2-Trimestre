<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title>Tipos de lenguajes de programación</title>
    <!--Bootstrap-->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <style>
      body {
        font-family: Arial, sans-serif;
        margin: 0;
        padding: 0;
        box-sizing: border-box;
      }

      /*Estilos para la cabecera*/
      #header-nav {
        background-color: #333;
        color: #fff;
        padding: 1em;
      }
      
      .navbar-brand {
        font-size: 2em;
      }
      
      .nav-link {
        color: #fff !important;
        font-size: 1.2em;
        margin-left: 1em;
      }
      
      .nav-link:hover {
        color: #f8f9fa !important;
      }

      /*Estilos para el contenido*/
      main {
        padding: 2em;
      }
      
      h1 {
        margin-bottom: 0.5em;
      }
      
      h2 {
        margin-top: 2em;
        margin-bottom: 1em;
      }
      
      p {
        font-size: 1.2em;
        line-height: 1.5;
      }
      
      ul {
        margin-top: 0;
        padding-left: 1.2em;
        font-size: 1.2em;
        line-height: 1.5;
      }
      
      li {
        margin-bottom: 0.5em;
      }
      
      a {
        color: #007bff;
      }
      
      a:hover {
        text-decoration: none;
        color: #0056b3;
      }
    </style>
  </head>
  <body>
    <div id="header-nav">
      <nav class="navbar navbar-expand-lg navbar-dark">
        <a class="navbar-brand" href="#">Tipos de lenguajes de programación</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse justify-content-end" id="navbarNavDropdown">
          <ul class="navbar-nav">
            <li class="nav-item">
              <a class="nav-link" href="formulario.php">Formulario</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="validar.php">Validar
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="entradas.php">Ver formularios
              </a>
            </li>
          </ul>
        </div>
      </nav>
    </div>
    </header>
    <main>
      <section id="1">
        <h2>Lenguajes orientados a objetos</h2>
        <p>Los lenguajes orientados a objetos (OO) se centran en la manipulación de objetos, que pueden ser definidos como una entidad que tiene un conjunto de atributos y métodos. Los atributos describen las características del objeto, mientras que los métodos representan las acciones que el objeto puede realizar.</p>
        <p>Algunos ejemplos de lenguajes de programación OO son Java, Python y Ruby.</p>
        <ul>
          <li>Los objetos son la unidad básica de la programación.</li>
          <li>Los objetos pueden interactuar entre sí.</li>
          <li>La programación OO permite la encapsulación, herencia y polimorfismo.</li>
        </ul>
      </section>
      <section id="2">
        <h2>Lenguajes orientados a eventos</h2>
        <p>Los lenguajes orientados a eventos se basan en la idea de que la interacción con el programa se realiza a través de eventos, que son acciones que el usuario realiza en la interfaz gráfica de usuario (GUI). El programa responde a estos eventos ejecutando un código asociado al evento.</p>
        <p>Algunos ejemplos de lenguajes de programación orientados a eventos son JavaScript, Visual Basic y C#.</p>
        <ul>
          <li>La interacción con el usuario se realiza a través de eventos.</li>
          <li>Los eventos pueden ser generados por el usuario o por el sistema.</li>
          <li>El código asociado a un evento se ejecuta cuando se produce el evento.</li>
        </ul>
      </section>
      <section id="3">
        <h2>Lenguajes procedimentales</h2>
        <p>Los lenguajes procedimentales se centran en la ejecución de procedimientos, que son secuenciasde instrucciones que realizan una tarea específica. Estos procedimientos pueden ser llamados desde diferentes partes del programa para realizar la tarea correspondiente. Los datos suelen ser almacenados en variables y manipulados mediante operaciones aritméticas y lógicas.</p>
        <p>Algunos ejemplos de lenguajes de programación procedimentales son C, Pascal y Fortran.</p>
        <ul>
        <li>Los procedimientos son la unidad básica de la programación.</li>
        <li>Los datos son manipulados mediante operaciones aritméticas y lógicas.</li>
        <li>La programación procedimental puede ser estructurada o modular.</li>
        </ul>
        </section>
        </main>

        </body>
        </html>