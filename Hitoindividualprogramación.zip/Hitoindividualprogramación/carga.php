<?php
// Establecer la conexión a la base de datos
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "hitoindividual2trimestre";

$conn = mysqli_connect($servername, $username, $password, $dbname);

// Comprobar si la conexión se ha establecido correctamente
if (!$conn) {
    die("Error al conectar a la base de datos: " . mysqli_connect_error());
}

// Obtener los datos del formulario
$author_email = $_POST['author_email'];
$title = $_POST['title'];
$content = $_POST['content'];
$publish_date = $_POST['publish_date'];
$image = $_FILES['image']['name'];

// Mover la imagen cargada a una carpeta en el servidor
if(isset($_FILES['image'])){
    $target_dir = "uploads/";
    $target_file = $target_dir . basename($_FILES['image']['name']);
    move_uploaded_file($_FILES['image']['tmp_name'], $target_file);
}

// Insertar los datos en la tabla "formulario"
$sql = "INSERT INTO formulario (email, titulo, fechapublicacion, imagen, contenido) VALUES ('$author_email', '$title', '$publish_date', '$image', '$content')";

if (mysqli_query($conn, $sql)) {
    echo "El post se ha creado correctamente.";
} else {
    echo "Error al crear el post: " . mysqli_error($conn);
}

// Cerrar la conexión a la base de datos
mysqli_close($conn);
header('Location: validar.php');
?>