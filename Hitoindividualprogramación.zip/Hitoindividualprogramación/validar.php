<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Agregamos los enlaces a Bootstrap -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.2/css/bootstrap.min.css" integrity="sha512-K8lqrcoBcfsSBCzvA/57nHb4NpsUS4F4bWRZ9uVpE8GmlPVxIZrPzE+onTcT1zUhWL0GYsMgOlhjXhtHfZ8oOQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <title>Validar</title>
</head>
<body>
    <style>
        body {
  font-family: Arial, sans-serif;
  background-color: #f5f5f5;
  color: #333;
}

/* Estilos para el contenedor principal */
.container {
  max-width: 800px;
  margin: auto;
  padding: 20px;
  background-color: #fff;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

/* Estilos para el título */
h1 {
  text-align: center;
  font-size: 2rem;
  margin-bottom: 30px;
  color: #333;
}

/* Estilos para el formulario */
form {
  display: flex;
  flex-direction: column;
}

.form-control {
  margin-bottom: 20px;
  padding: 10px;
  border-radius: 5px;
  border: 1px solid #ccc;
}

.form-control:focus {
  border-color: #007bff;
  box-shadow: 0 0 5px rgba(0, 123, 255, 0.5);
}

.form-control::placeholder {
  color: #999;
}

/* Estilos para el botón */
.btn {
  display: inline-block;
  padding: 10px 20px;
  border-radius: 5px;
  border: none;
  color: #fff;
  font-size: 1rem;
  text-align: center;
  cursor: pointer;
}

.btn-primary {
  background-color: #007bff;
}

.btn-primary:hover {
  background-color: #0069d9;
}

.btn-secondary {
  background-color: #6c757d;
}

.btn-secondary:hover {
  background-color: #5a6268;
}

/* Estilos para el mensaje de éxito */
.alert-success {
  margin-top: 20px;
  padding: 10px;
  border-radius: 5px;
  background-color: #28a745;
  color: #fff;
  font-weight: bold;
}

/* Estilos para el mensaje de error */
.alert-danger {
  margin-top: 20px;
  padding: 10px;
  border-radius: 5px;
  background-color: #dc3545;
  color: #fff;
  font-weight: bold;
}
</style>
    <div class="container mt-5">
        <form method="post">
            <div class="mb-3">
                <label for="email" class="form-label">Dirección de correo</label>
                <input type="email" class="form-control" id="email" name="email">
            </div>
            <div class="mb-3">
                <label for="contraseña" class="form-label">Contraseña</label>
                <input type="password" class="form-control" id="contraseña" name="contraseña">
            </div>
            <!-- Corregimos el tipo de botón y agregamos clases de Bootstrap -->
            <button type="submit" class="btn btn-primary">Enviar</button>
        </form>

        <?php
        if (isset($_POST['email']) && isset($_POST['contraseña'])) {
            session_start();
            $token = session_id();
            // Mostramos el mensaje dentro de un alerta de Bootstrap
            echo '<div class="alert alert-success mt-3" role="alert">Ha iniciado sesión con su ID: ' . $token . '</div>';
        }
        ?>

    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.2/js/bootstrap.bundle.min.js" integrity="sha512-6GjH9jylzvZIcQZoYsLsRQmqiMcEnN4c4zuN4A32zj6fMpz/fUPhbGZS57TJjH0x2OyPV6yoI4UX4bgf6pLq6A==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
</body>
</html>